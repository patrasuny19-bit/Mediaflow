import type { MediaMetadata, MediaFormat } from "../types.js";

export interface MediaProvider {
  name: string;
  canHandle(url: URL): boolean;
  getMetadata(url: URL): Promise<MediaMetadata>;
  getFormats(url: URL): Promise<MediaFormat[]>;
  requestAuthorizedDownload(url: URL, format: MediaFormat): Promise<{ path: string; mime: string; filename: string }>;
}
